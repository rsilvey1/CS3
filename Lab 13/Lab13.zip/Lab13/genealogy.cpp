#include <iostream>
#include <string>
#include <vector>

using std::cout; using std::endl;
using std::string; 
using std::vector;

class Person {
public:
    Person(string firstName, Person* spouse, Person* father, Person* mother):
        firstName_(firstName), spouse_(spouse), father_(father), mother_(mother) {}

    string getFirstName() { return firstName_; }
    Person* getSpouse() { return spouse_; }
    void setSpouse(Person* spouse) { spouse_ = spouse; }
    Person* getFather() { return father_; }
    Person* getMother() { return mother_; }

    virtual const vector<Person*>& getChildren() {
        // Implement this method in derived classes as needed
        // For classes without children, return an empty vector
        static vector<Person*> empty;
        return empty;
    }

    virtual void accept(class PersonVisitor*) = 0;  
    virtual ~Person() {}
    
private:
    string firstName_;
    Person* spouse_;
    Person* father_;
    Person* mother_;
};

class Man : public Person {
public:
    Man(string lastName, string firstName, Person* spouse, Person* father, Person* mother): 
        lastName_(lastName), Person(firstName, spouse, father, mother) {}

    string getLastName() { return lastName_; }
    void accept(class PersonVisitor* visitor) override;

private:
    string lastName_;
};

class Woman : public Person {
public: 
    Woman(vector<Person*> children, string firstName, Person* spouse, Person* father, Person* mother): 
        children_(children), Person(firstName, spouse, father, mother) {}

    const vector<Person*>& getChildren() { return children_; }
    void setChildren(const vector<Person*>& children) { children_ = children; }
    void accept(class PersonVisitor* visitor) override;

private:
    vector<Person*> children_;
}; 

class PersonVisitor {
public:
    virtual void visit(Man*) = 0;
    virtual void visit(Woman*) = 0;
    virtual ~PersonVisitor() {}
};

void Man::accept(PersonVisitor* visitor) {
    visitor->visit(this);
}

void Woman::accept(PersonVisitor* visitor) {
    visitor->visit(this);
    for (auto child : children_)
        child->accept(visitor);
}

class MaidenNamePrinter : public PersonVisitor {
public:
    void visit(Man* m) override {
        cout << m->getFirstName() << " " << m->getLastName() << endl;
    }

    void visit(Woman* w) override {
        cout << w->getFirstName() << " ";
        if (w->getFather() != nullptr)
            cout << static_cast<Man*>(w->getFather())->getLastName();
        else
            cout << "Doe";
        cout << endl;
    }
};

class MarriageChecker : public PersonVisitor {
public:
    MarriageChecker(string candidate1, string candidate2) :
        candidate1_(candidate1), candidate2_(candidate2), canMarry_(true) {}

    void visit(Man* m) override {
        checkMarriageRules(m);
    }

    void visit(Woman* w) override {
        checkMarriageRules(w);
    }

    bool canMarry() const {
        return canMarry_;
    }

private:
    void checkMarriageRules(Person* person) {
        if (person->getFirstName() == candidate1_ || person->getFirstName() == candidate2_) {
            Person* otherCandidate = (person->getFirstName() == candidate1_) ? findPerson(candidate2_) : findPerson(candidate1_);

            if (otherCandidate != nullptr) {
                if (isIllegalRelationship(person, otherCandidate) || isIllegalRelationship(otherCandidate, person)) {
                    canMarry_ = false;
                }
            } else {
                canMarry_ = false;
            }
        }
    }

    bool isIllegalRelationship(Person* person, Person* candidate) const {
        return (person->getFather() == candidate || person->getMother() == candidate ||
                person->getSpouse() == candidate || isDescendant(person, candidate));
    }

    bool isDescendant(Person* ancestor, Person* descendant) const {
        for (auto child : ancestor->getChildren()) {
            if (child == descendant || isDescendant(child, descendant)) {
                return true;
            }
        }
        return false;
    }

    Person* findPerson(const string& firstName) const {
        // Implement the search logic based on your data structure
        // Return nullptr if not found
        return nullptr;
    }

    string candidate1_;
    string candidate2_;
    bool canMarry_;
};

class NamePrinter : public PersonVisitor {
public:
    void visit(Man* m) override;
    void visit(Woman* w) override;
};

void NamePrinter::visit(Man *m) {
    cout << m->getFirstName() << " " << m->getLastName() << endl;
}

void NamePrinter::visit(Woman *w) {
    cout << w->getFirstName() << " ";
    if (w->getSpouse() != nullptr)
        cout << static_cast<Man*>(w->getSpouse())->getLastName();
    else if (w->getFather() != nullptr)
        cout << static_cast<Man*>(w->getFather())->getLastName();
    else
        cout << "Doe";
    cout << endl;
}

class ChildrenPrinter : public PersonVisitor {
public:
    void visit(Man *m) {
        cout << m->getFirstName() << ": ";
        Woman *spouse = static_cast<Woman*>(m->getSpouse());
        if (spouse != nullptr)
            printNames(spouse->getChildren());
        cout << endl;
    }

    void visit(Woman *w) {
        cout << w->getFirstName() << ": ";
        printNames(w->getChildren());
        cout << endl;
    }

private:
    void printNames(const vector<Person*>& children) {
        for (const auto c : children)
            cout << c->getFirstName() << ", ";
    }
};

int main() {
    Man *js = new Man("Smith", "James", nullptr, nullptr, nullptr);
    Woman *ms = new Woman({}, "Mary", nullptr, nullptr, nullptr);
    ms->setSpouse(js); js->setSpouse(ms);

    Woman *ps = new Woman({}, "Patricia", nullptr, js, ms);
    Man *wj = new Man("Johnson", "William", nullptr, nullptr, nullptr);
    ps->setSpouse(wj); wj->setSpouse(ps);

    vector<Person*> marysKids = { ps,
                                  new Man("Smith", "Robert", nullptr, js, ms),
                                  new Woman({}, "Linda", nullptr, js, ms) };
    ms->setChildren(marysKids);

    Man *mj = new Man("Johnson", "Michael", nullptr, wj, ps);
    vector<Person*> patsKids = { mj,
                                 new Woman({}, "Barbara", nullptr, wj, ps) }; 
    ps->setChildren(patsKids);

    Woman *jj = new Woman({}, "Jennifer", nullptr, nullptr, nullptr);
    vector<Person*> jensKids = { new Woman({}, "Susan", nullptr, mj, jj) };

    jj->setSpouse(mj); mj->setSpouse(jj);
    jj->setChildren(jensKids);

    MaidenNamePrinter* maidenNamePrinter = new MaidenNamePrinter;
    cout << "MAIDEN NAMES\n";
    ms->accept(maidenNamePrinter);

    string candidate1, candidate2;
    cout << "\nEnter first candidate: ";
    getline(std::cin, candidate1);
    cout << "Enter second candidate: ";
    getline(std::cin, candidate2);

    MarriageChecker* marriageChecker = new MarriageChecker(candidate1, candidate2);
    ms->accept(marriageChecker);

    if (marriageChecker->canMarry()) {
        cout << "They can marry." << endl;
    } else {
        cout << "They can not marry." << endl;
    }

    // Cleanup
    delete maidenNamePrinter;
    delete marriageChecker;

    return 0;
}