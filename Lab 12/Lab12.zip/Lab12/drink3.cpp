#include <iostream>
#include <string>
#include <ctime>

enum class DrinkType { small, medium, large };

class Barista;

class Drink {
public:
    virtual ~Drink() {}
    virtual int getPrice() const = 0;
    virtual std::string getName() const = 0;
    virtual void setBarista(Barista* barista) = 0;
};

class Coffee : public Drink {
public:
    Coffee(DrinkType type = DrinkType::small) : type_(type), price_(0), barista_(nullptr) {}

    int getPrice() const override;
    std::string getName() const override;
    void setBarista(Barista* barista) override;

private:
    DrinkType type_;
    int price_;
    Barista* barista_;
};

class Barista {
public:
    virtual ~Barista() {}
    virtual void handleRequest(Drink* drink) = 0;
    virtual void setNextBarista(Barista* nextBarista) = 0;
};

class JuniorBarista : public Barista {
public:
    void handleRequest(Drink* drink) override;
    void setNextBarista(Barista* nextBarista) override;
};

class SeniorBarista : public Barista {
public:
    void handleRequest(Drink* drink) override;
    void setNextBarista(Barista* nextBarista) override;
};

class Manager : public Barista {
public:
    void handleRequest(Drink* drink) override;
    void setNextBarista(Barista* nextBarista) override;
};




int main() {
    srand(static_cast<unsigned>(time(nullptr)));

    char size;
    std::cout << "Welcome to Coffee Shack, can I get you [l]arge, [m]edium, or [s]mall coffee? ";
    std::cin >> size;

    DrinkType drinkType;
    switch (size) {
        case 's':
        case 'S':
            drinkType = DrinkType::small;
            break;
        case 'm':
        case 'M':
            drinkType = DrinkType::medium;
            break;
        case 'l':
        case 'L':
            drinkType = DrinkType::large;
            break;
        default:
            std::cerr << "Invalid size selection." << std::endl;
            return 1;
    }

    Drink* coffee = new Coffee(drinkType);  // Create a Coffee object

    // Create the Barista chain
    Barista* juniorBarista = new JuniorBarista();
    Barista* seniorBarista = new SeniorBarista();
    Barista* manager = new Manager();

    // Set up the chain of responsibility
    juniorBarista->setNextBarista(seniorBarista);
    seniorBarista->setNextBarista(manager);

    // Handle the request with the chain
    juniorBarista->handleRequest(coffee);

    delete coffee;
    delete juniorBarista;
    delete seniorBarista;
    delete manager;

    return 0;
}

