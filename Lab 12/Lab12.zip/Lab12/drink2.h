// drink class to be used in Coffee Shack lab
// Wayne Cheng
// 4/10/2018

#include <vector>
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <chrono>
#include <thread>

class Customer; // Forward declaration

enum class DrinkType { small, medium, large };

class Barista {
public:
    virtual ~Barista() = default;
    virtual void registerCustomer(Customer* customer) = 0;
    virtual void removeCustomer(Customer* customer) = 0;
    virtual void notifyCustomers() = 0;
};

class Customer {
public:
    virtual ~Customer() = default;
    virtual void update(const std::string& message) = 0;
};

class Drink : public Barista {
public:
    Drink(DrinkType type = DrinkType::small) : type_(type), price_(getPriceByType(type)) {}

    int getPrice() const {
        return price_;
    }

    std::string getName() const {
        switch (type_) {
            case DrinkType::small:
                return "small coffee";
            case DrinkType::medium:
                return "medium coffee";
            case DrinkType::large:
                return "large coffee";
            default:
                return "unknown size coffee";
        }
    }

    void prepare() {
        // Logic to prepare the drink

        // Notify customers when the drink is ready
        notifyCustomers();
    }

    // Implement Barista interface
    void registerCustomer(Customer* customer) override {
        customers_.push_back(customer);
    }

    void removeCustomer(Customer* customer) override {
        // Implement if needed
    }
    void notifyCustomers() override {
        for (Customer* customer : customers_) {
            customer->update("Your drink is ready: " + getName());
        }
    }

private:
    static int getPriceByType(DrinkType type) {
        switch (type) {
            case DrinkType::small:
                return 100; // $1.00
            case DrinkType::medium:
                return 200; // $2.00
            case DrinkType::large:
                return 300; // $3.00
            default:
                return 0;
        }
    }

    DrinkType type_;
    int price_;
    std::vector<Customer*> customers_;
};
