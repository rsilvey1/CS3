#pragma once

#include <string>

enum class DrinkType { small, medium, large };

class Drink {
public:
    Drink(DrinkType type = DrinkType::small, int price = 0) : type_(type), price_(price) {}
    virtual ~Drink() {}

    virtual int getPrice() const = 0;
    virtual std::string getName() const = 0;

    DrinkType getType() const { return type_; }
    int getPrice_() const { return price_; }

protected:
    int price_;
    DrinkType type_;
};
