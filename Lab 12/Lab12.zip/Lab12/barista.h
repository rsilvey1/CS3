#pragma once

#include <string>
#include "drink3.h"

class Barista {
public:
    virtual void handleRequest(Drink* drink) = 0;
};

class JuniorBarista : public Barista {
public:
    void handleRequest(Drink* drink) override;
};

class SeniorBarista : public Barista {
public:
    void handleRequest(Drink* drink) override;
};

class Manager : public Barista {
public:
    void handleRequest(Drink* drink) override;
};
