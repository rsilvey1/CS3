#include "drink1.h"
#include <iostream>


/*
class Coffee : public Drink {
public:
    Coffee(DrinkType type) : Drink(type, getPriceByType(type)) {}

    int getPrice() const override {
        return getPriceByType(type_);
    }

    std::string getName() const override {
        switch (type_) {
            case DrinkType::small:
                return "small coffee";
            case DrinkType::medium:
                return "medium coffee";
            case DrinkType::large:
                return "large coffee";
            default:
                return "unknown size coffee";
        }
    }

private:
    static int getPriceByType(DrinkType type) {
        switch (type) {
            case DrinkType::small:
                return 100; // $1.00
            case DrinkType::medium:
                return 200; // $2.00
            case DrinkType::large:
                return 300; // $3.00
            default:
                return 0;
        }
    }
};
*/

class Coffee : public Drink {
public:
    Coffee(DrinkType type) : Drink(type, getPriceByType(type)) {}

    int getPrice() const override {
        return getPriceByType(type_);
    }

    std::string getName() const override {
        switch (type_) {
            case DrinkType::small:
                return "small coffee";
            case DrinkType::medium:
                return "medium coffee";
            case DrinkType::large:
                return "large coffee";
            default:
                return "unknown size coffee";
        }
    }

private:
    static int getPriceByType(DrinkType type) {
        switch (type) {
            case DrinkType::small:
                return 100; // $1.00
 case DrinkType::medium:
                return 200; // $2.00
            case DrinkType::large:
                return 300; // $3.00
            default:
                return 0;
        }
    }
};


///////////////////////////////////



class SprinklesDecorator : public Drink {
public:
    SprinklesDecorator(Drink* baseDrink) : baseDrink_(baseDrink), Drink(baseDrink->getType(), baseDrink->getPrice_() + 50) {}

    int getPrice() const override {
        return baseDrink_->getPrice_() + 50;
    }

    std::string getName() const override {
        return baseDrink_->getName() + ", sprinkles";
    }

private:
    Drink* baseDrink_;
};

class CaramelDecorator : public Drink {
public:
    CaramelDecorator(Drink* baseDrink) : baseDrink_(baseDrink), Drink(baseDrink->getType(), baseDrink->getPrice_() + 20) {}

    int getPrice() const override {
        return baseDrink_->getPrice_() + 20;
    }

    std::string getName() const override {
        return baseDrink_->getName() + ", caramel";
    }

private:
    Drink* baseDrink_;
};

class MilkFoamDecorator : public Drink {
public:
    MilkFoamDecorator(Drink* baseDrink) : baseDrink_(baseDrink), Drink(baseDrink->getType(), baseDrink->getPrice_() + 40) {}

    int getPrice() const override {
        return baseDrink_->getPrice_() + 40;
    }

    std::string getName() const override {
        return baseDrink_->getName() + ", milk foam";
    }

private:
    Drink* baseDrink_;
};
class IceDecorator : public Drink {
public:
    IceDecorator(Drink* baseDrink) : baseDrink_(baseDrink), Drink(baseDrink->getType(), baseDrink->getPrice_() + 10) {}

    int getPrice() const override {
        return baseDrink_->getPrice_() + 10;
    }

    std::string getName() const override {
        return baseDrink_->getName() + ", ice";
    }

private:
    Drink* baseDrink_;
};

int main() {
    char size;
    std::cout << "Welcome to Coffee Shack, can I get you [l]arge, [m]edium, or [s]mall coffee? ";
    std::cin >> size;

    Drink* coffee = new Coffee(static_cast<DrinkType>(size));

    char choice;
    do {
        std::cout << "Would you like to add [s]prinkles, [c]aramel, milk [f]oam, [i]ce or [n]ot? ";
        std::cin >> choice;

        switch (choice) {
            case 's':
                coffee = new SprinklesDecorator(coffee);
                break;
            case 'c':
                coffee = new CaramelDecorator(coffee);
                break;
            case 'f':
                coffee = new MilkFoamDecorator(coffee);
                break;
            case 'i':
                coffee = new IceDecorator(coffee);
                break;
            default:
                break;
        }

    } while (choice != 'n');

    std::string name;
    std::cout << "Can I get your name? ";
    std::cin >> name;

    std::cout << name << ", your " << coffee->getName() << " is ready. It will be $" << coffee->getPrice_() / 100.0 << ", please." << std::endl;
}
