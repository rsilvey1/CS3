#include "drink2.h"

class Coffee : public Drink {
public:
    Coffee(DrinkType type) : Drink(type) {}

    // Override getPrice and getName if needed

    // Additional methods for the Coffee class
};

class RegularCustomer : public Customer {
public:
    explicit RegularCustomer(const std::string& name) : name_(name) {}

    void update(const std::string& message) override {
        std::cout << name_ << ", " << message << std::endl;
    }

private:
    std::string name_;
};

int main() {

  srand(static_cast<unsigned>(time(nullptr)));

    char size;
    std::cout << "Welcome to Coffee Shack, can I get you [l]arge, [m]edium, or [s]mall coffee? ";
    std::cin >> size;

    DrinkType drinkType;


    switch (size) {
    case 's':
    case 'S':
        drinkType = DrinkType::small;
        break;
    case 'm':
    case 'M':
        drinkType = DrinkType::medium;
        break;
    case 'l':
    case 'L':
        drinkType = DrinkType::large;
        break;
    default:
        std::cerr << "Invalid size selection." << std::endl;
        return 1;
}
    /*switch (size) {
        case 's':
            drinkType = DrinkType::small;
            break;
        case 'm':
            drinkType = DrinkType::medium;
            break;
        case 'l':
            drinkType = DrinkType::large;
            break;
        default:
            std::cerr << "Invalid size selection." << std::endl;
            return 1;
    }*/

    Drink* coffee = new Coffee(drinkType);


  /*
    srand(static_cast<unsigned>(time(nullptr)));

    char size;
    std::cout << "Welcome to Coffee Shack, can I get you [l]arge, [m]edium, or [s]mall coffee? ";
    std::cin >> size;

    Drink* coffee = new Coffee(static_cast<DrinkType>(size));*/

    std::vector<Customer*> customers;
    customers.push_back(new RegularCustomer("Alex"));
    customers.push_back(new RegularCustomer("Bob"));
    customers.push_back(new RegularCustomer("Charlie"));

    // Register customers with the barista
    for (Customer* customer : customers) {
        coffee->registerCustomer(customer);
    }

    // Simulate the barista preparing drinks and notifying customers
    for (int i = 0; i < 5; ++i) {
        coffee->prepare();

        // Simulate some delay before taking the next order
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }

    // Clean up
    for (Customer* customer : customers) {
        delete customer;
    }

    delete coffee;

    return 0;
}
