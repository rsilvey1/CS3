#include "barista.h"
#include <iostream>

void JuniorBarista::handleRequest(Drink* drink) {
    // Junior Barista can only prepare drinks with no added ingredients
    std::cout << "Junior Barista is preparing the order." << std::endl;
}

void SeniorBarista::handleRequest(Drink* drink) {
    // Senior Barista can handle added ingredients except for milk foam
    std::cout << "Senior Barista is preparing the order with added ingredients." << std::endl;
}

void Manager::handleRequest(Drink* drink) {
    // Manager can handle all ingredients
    std::cout << "Manager is preparing the order with all ingredients." << std::endl;
}
