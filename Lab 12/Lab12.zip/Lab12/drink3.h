// drink class to be used in Coffee Shack lab
// Wayne Cheng
// 4/10/2018

#pragma once

#include <string>

enum class DrinkType { small, medium, large };

class Barista; // Forward declaration

class Drink {
public:
    Drink(DrinkType type = DrinkType::small) : type_(type) {}
    void prepare(Barista* barista);
    virtual std::string getName() const;
private:
    DrinkType type_;
};

// drink.cpp
#include "drink3.h"
#include "barista.h"

void Drink::prepare(Barista* barista) {
    barista->handleRequest(this);
}

std::string Drink::getName() const {
    switch (type_) {
        case DrinkType::small:
            return "small coffee";
        case DrinkType::medium:
            return "medium coffee";
        case DrinkType::large:
            return "large coffee";
        default:
            return "unknown size coffee";
    }
}
