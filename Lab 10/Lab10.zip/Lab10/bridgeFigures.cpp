// Modification made by: Ronnie Silvey
//Date: 12/06/2023




#include <iostream>

using std::cout;
using std::endl;
using std::cin;

// abstract body
class Fill
{
public:
    Fill(char borderChar, char internalChar) : borderChar_(borderChar), internalChar_(internalChar) {}
    virtual char getBorder() = 0;
    virtual char getInternal() = 0;
    virtual ~Fill() {}

protected:
    char borderChar_;
    char internalChar_;
};

// concrete body
class Hollow : public Fill
{
public:
    Hollow(char fillChar) : Fill(fillChar, ' ') {}
    char getBorder() override { return borderChar_; }
    char getInternal() override { return internalChar_; }
    ~Hollow() {}
};

// another concrete body
class Filled : public Fill
{
public:
    Filled(char fillChar) : Fill(fillChar, fillChar) {}
    char getBorder() override { return borderChar_; }
    char getInternal() override { return internalChar_; }
    ~Filled() {}
};

// enhanced filled class
class EnhancedFilled : public Filled
{
public:
    EnhancedFilled(char borderChar, char internalChar) : Filled(borderChar), enhancedInternalChar_(internalChar) {}
    char getInternal() override { return enhancedInternalChar_; }
    ~EnhancedFilled() {}

private:
    char enhancedInternalChar_;
};


// abstract handle
class Figure
{
public:
    Figure(int size, Fill *fill) : size_(size), fill_(fill) {}
    virtual void draw() = 0;
    virtual ~Figure() {}

protected:
    int size_;
    Fill *fill_;
};

// concrete handle
class Square : public Figure
{
public:
    Square(int size, Fill *fill) : Figure(size, fill) {}
    void draw() override;
    ~Square() {}
};

void Square::draw()
{
    for (int i = 0; i < size_; ++i)
    {
        for (int j = 0; j < size_; ++j)
            if (i == 0 || j == 0 || i == size_ - 1 || j == size_ - 1)
                cout << fill_->getBorder();
            else
                cout << fill_->getInternal();
        cout << endl;
    }
}

int main()
{
    Fill *hollowPaintY = new Hollow('Y');
    Fill *filledPaintStar = new Filled('*');
    Fill *enhancedFilledPaint = new EnhancedFilled('@', '+');

    Figure *smallBox = new Square(4, filledPaintStar);
    Figure *bigBox = new Square(10, hollowPaintY);
    Figure *enhancedBox = new Square(6, enhancedFilledPaint);

    cout << "Small Box:" << endl;
    smallBox->draw();
    cout << endl;

    cout << "Big Box:" << endl;
    bigBox->draw();
    cout << endl;

    cout << "Enhanced Box:" << endl;
    enhancedBox->draw();
    cout << endl;

    // Clean up memory
    delete hollowPaintY;
    delete filledPaintStar;
    delete enhancedFilledPaint;

    delete smallBox;
    delete bigBox;
    delete enhancedBox;

    return 0;
}

