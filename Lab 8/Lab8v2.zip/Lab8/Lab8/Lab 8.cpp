// Program to demonstrate the Singleton design pattern
// Created by: Ronnie Silvey
// Date: 10/19/2023

#include <iostream>
#include <fstream>
#include <string>

#include "Logger.h"

using std::string;
using std::ofstream;
using std::cout;
using std::endl;
using std::cin;



// make the instancePtr a nullptr
Logger* Logger::instancePtr = nullptr;



// stuff for the atexit
void writeAtExit() {
	Logger* log = Logger::getInstance();
	ofstream logFile("Log.txt");

	if (logFile.is_open()) {
		logFile << log->getData();
		cout << "Written to the file successfully!" << endl;
		
		// close the file after writing
		logFile.close();
	}

}



int main()
{
	// the current line the user is typing
	string currentLine;

	// instance of the log
	Logger* myLog = Logger::getInstance();

	// sets atexit to use the writeAtExit function
	std::atexit(writeAtExit);



	cout << "Enter text to be written to the log file. Type \"exit\" to exit: " << endl;
	while (currentLine != "exit") {
		cin >> currentLine;

		myLog->addData(currentLine);
	}




	// doing a test to make sure we are only getting one instance
	Logger* testLog = Logger::getInstance();

	if (testLog == myLog) cout << "The loggers are the same!" << endl;
	else cout << "The loggers are not the same :(" << endl;
	

	return 0;
}