// File to implement the Logger class
// Created by: Ronnie Silvey
// Date: 10/19/2023

#include <string>

using std::string;



// logger class
class Logger {
public: 
	// function to report
	void report(string& str);

	// get the data
	string getData() { return data; };

	// add the string to the data
	void addData(string str) { if (str.find("exit") == string::npos)  data.append(str + ' '); };

	// delete functions
	Logger(const Logger& obj);




	// get the current instance or make a new one
	static Logger* getInstance() {
		if (instancePtr == nullptr) {
			// if it's equal to nullptr, we don't already have an instance and need to make a new one
			instancePtr = new Logger();
			return instancePtr;
		}
		else {
			// if it's something other than nullptr, we already have an instance
			return instancePtr;
		}
	};
	
private:
	// member variables
	string data;

	static Logger* instancePtr;


	

	// constructor, overload assignment
	Logger() { data = ""; };


	

	// overload operator=
	Logger operator=(const Logger);


	// Copy assignment operator
	Logger& operator=(const Logger& other) {
		if (this != &other) {  // Check for self-assignment
			data = other.data;
		}
		return *this;
	}
	
};


// Copy constructor
Logger::Logger(const Logger& obj) {
	data = obj.data;
}

void Logger::report(string &str) {
	// add the current text onto the existing data
	data.append(str);

}



Logger Logger::operator=(const Logger other) {
	if (this != &other) {  // Check for self-assignment
		data = other.data;
	}
	return *this;
}