#include <iostream>
#include <fstream>
#include <string>
#include <istream>

using namespace std;

int countSpaces(string f1, string f2, string name1) {
    // used to determine where to put the carrot
    bool firstDiff = true;

    // counter variable
    int i = 0;
    int finalCount;

    while (f1[i] == f2[i]) {
        ++i;
    }

    finalCount = i;
    i = 0;

    while (name1[i] != '\0') {
        ++i;
    }

    finalCount += i;

    // 2 is the offset below for the spaces and colons
    return finalCount + 2;
}

int main(int argc, char* argv[]) {
    string f1, f2;
    const string name1 = argv[1];
    const string name2 = argv[2];

    int lineNum;

    // open the files
    ifstream file1(name1);
    ifstream file2(name2);

    while (!file1.eof() || !file2.eof()) {
        // used to determine where to put the carrot
        bool firstDiff = true;

        // gets the lines of both files
        if (!file1.eof()) {
            getline(file1, f1);
        }
        else {
            f1 = "";
        }
        if (!file2.eof()) {
            getline(file2, f2);
        }
        else {
            f2 = "";
        }

        if (f1 != f2) {
            // determine the point to put the carrot
            int numSpaces;
            numSpaces = countSpaces(f1, f2, name1);

            // print the strings and carrot
            cout << name1 << ": " << f1 << endl;
            cout << name2 << ": " << f2 << endl;

            // print the spaces
            for (int i = 0; i < numSpaces; ++i) {
                cout << " ";
            }
            cout << "^" << endl;

        }
        else {
            // just print the lines of text =)
            cout << name1 << ": " << f1 << endl;
            cout << name2 << ": " << f2 << endl;
        }

    }
}
