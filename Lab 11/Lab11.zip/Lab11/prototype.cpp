#include <iostream>
#include <queue>
#include <cstdlib>
#include <ctime>

// Process states
enum class ProcessState {
    New,
    Ready,
    Running,
    Waiting,
    Terminated
};

// Forward declaration of Process class
class Process;

// State interface
class ProcessStateInterface {
public:
    virtual void schedulerDispatch(Process& process) = 0;
    virtual void reportState(int processId) = 0;
};

// Concrete state classes
class NewState : public ProcessStateInterface {
public:
    void schedulerDispatch(Process& process) override;
    void reportState(int processId) override;
};

class ReadyState : public ProcessStateInterface {
public:
    void schedulerDispatch(Process& process) override;
    void reportState(int processId) override;
};

class RunningState : public ProcessStateInterface {
public:
    void schedulerDispatch(Process& process) override;
    void reportState(int processId) override;
};

class WaitingState : public ProcessStateInterface {
public:
    void schedulerDispatch(Process& process) override;
    void reportState(int processId) override;
};

class TerminatedState : public ProcessStateInterface {
public:
    void schedulerDispatch(Process& process) override;
    void reportState(int processId) override;
};

// Process class using State Design Pattern
class Process {
public:
    ProcessStateInterface* state;
    int processId;

    Process() : processId(nextProcessId()), state(new NewState()) {}

    void schedulerDispatch() {
        state->schedulerDispatch(*this);
    }

    void reportState() {
        state->reportState(processId);
    }

private:
    static int nextProcessId() {
        static int nextId = 1;
        return nextId++;
    }
};

// Concrete state implementations

void NewState::schedulerDispatch(Process& process) {
    process.state = new ReadyState();
}

void NewState::reportState(int processId) {
    std::cout << "Process " << processId << " is in New state." << std::endl;
}

void ReadyState::schedulerDispatch(Process& process) {
    srand(time(0));
    int random = rand() % 3;

    switch (random) {
        case 0:
            process.state = new RunningState();
            break;
        case 1:
            process.state = new WaitingState();
            break;
        case 2:
            process.state = new TerminatedState();
            break;
    }
}

void ReadyState::reportState(int processId) {
    std::cout << "Process " << processId << " is in Ready state." << std::endl;
}

void RunningState::schedulerDispatch(Process& process) {
    srand(time(0));
    int random = rand() % 3;

    switch (random) {
        case 0:
            process.state = new TerminatedState();
            break;
        case 1:
            process.state = new ReadyState();
            break;
        case 2:
            process.state = new WaitingState();
            break;
    }
}

void RunningState::reportState(int processId) {
    std::cout << "Process " << processId << " is in Running state." << std::endl;
}

void WaitingState::schedulerDispatch(Process& process) {
    srand(time(0));
    int random = rand() % 2;

    if (random == 0) {
        process.state = new ReadyState();
    }
}

void WaitingState::reportState(int processId) {
    std::cout << "Process " << processId << " is in Waiting state." << std::endl;
}

void TerminatedState::schedulerDispatch(Process& process) {
    // No further state transition for terminated process
}

void TerminatedState::reportState(int processId) {
    std::cout << "Process " << processId << " is in Terminated state." << std::endl;
}

int main() {
    std::queue<Process> processQueue;

    // Admit and schedule 4 new processes
    for (int i = 0; i < 4; ++i) {
        Process newProcess;
        processQueue.push(newProcess);
        newProcess.reportState();
    }

    // Simulate scheduler dispatch for each process
    while (!processQueue.empty()) {
        Process& currentProcess = processQueue.front();
        currentProcess.schedulerDispatch();
        currentProcess.reportState();
        
        if (currentProcess.state == nullptr) {
            // Process is terminated, remove from the queue
            processQueue.pop();
        } else {
            // Move the process to the end of the queue
            processQueue.push(currentProcess);
            processQueue.pop();
        }
    }

    return 0;
}