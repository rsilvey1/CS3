// vector and list algorithms
// Wayne Cheng
// 1/21/2018



// revisions by
// Ronnie Silvey
// 09/21/2023

#include <fstream>
#include <iostream>
#include <vector>
#include <list>
#include <string>
#include <cstdlib>
#include <map>
using namespace std;
/*
using std::ifstream;
using std::string; using std::getline;
using std::list; using std::vector;
using std::cout; using std::endl;
using std::move;
*/

// reading a list from a fileName
void readRoster(list<string>& roster, string fileName);
// printing a list out
void printRoster(const vector<list<string>>& roster);

void printRoster(const list<string>& str) { for (auto e : str) cout << e << endl; };



// my code

// code to see if a student is in a file
bool findStudent(list<string>& roster, string student);

// function to remove the .txt from the file name to add it to the list
string removeTxt(string str);


// function to check a specified text file for a student
bool isInTxt(string studentName, string fileName);


int main(int argc, char* argv[])
{
    if (argc <= 1)
    {
        cout << "usage: " << argv[0] << " list of courses, dropouts last" << endl;
        exit(1);
    }

    vector<list<string>> courseStudents;
    // making this a map
    map<string, list<string>> studentEntries;

    for (int i = 1; i < argc /*- 1*/; ++i)
    {
        list<string> roster;
        readRoster(roster, argv[i]);
        cout << "\n\n" << argv[i] << "\n";
        printRoster(roster);
        courseStudents.push_back(move(roster));
    }

    list<string> dropouts;
    readRoster(dropouts, argv[argc - 1]);
    cout << "\n\n dropouts \n";
    printRoster(dropouts);

    list<string> allStudents;

    for (auto& lst : courseStudents)
        allStudents.splice(allStudents.end(), lst);

    cout << "\n\n all students unsorted \n";
    printRoster(allStudents);

    allStudents.sort();
    cout << "\n\n all students sorted \n";
    printRoster(allStudents);

    allStudents.unique();
    cout << "\n\n all students, duplicates removed \n";
    printRoster(allStudents);

    for (const auto& str : dropouts)
    {
        allStudents.remove(str);
    }

    cout << "\n\n all students, dropouts removed \n";
    printRoster(allStudents);

    // ok, from here, we have just a list<string> with names in it
    // we can go through, search for each student in each file, add them to the map as we get them


    // loop through all students...
    for (auto e : allStudents) {
        for (int i = 1; i < argc /*- 1*/; ++i) {

            list<string> currentFile;
            readRoster(currentFile, argv[i]);
            
            // check if the user is in the current file
            for (auto a : currentFile) {
                if (e == a) {
                    //cout << "User " << e << " is found in the current file!" << endl;
                    // if they are, we need to see if they're already in the map
                    auto userHere = studentEntries.find(e);
                    if (userHere != studentEntries.cend()) {
                        //cout << "Student found!!" << endl;
                        
                        userHere->second.push_back(removeTxt(argv[i]));
                    }
                    else {
                        //cout << "Student not found in the map!" << endl;
                        // if they aren't in the map, add them
                        list<string> temp;
                        temp.push_back(removeTxt(argv[i]));
                        studentEntries.insert(std::pair<string, list<string>>(e, temp));
                    }
                }
            }
        }
    }
    cout << endl;
    cout << endl;
    cout << "Printing all students and classes" << endl;
    for (auto e : studentEntries) {
        cout << e.first << " ";
        for (auto a : e.second) {
            cout << a << " ";
        }
        cout << endl;
    }




    /*
    for (auto& e : allStudents)
    {
        list<string> currentStudent;

        for (int i = 1; i < argc - 1; ++i)
        {
            if (isInTxt(e, argv[i]))
            {
                currentStudent.push_back(removeTxt(argv[i]));
            }
        }

        if (!currentStudent.empty())
        {
            currentStudent.push_back(e);
            studentEntries.insert(currentStudent);
        }
    }*/
    /*const vector<list<string>>& test = studentEntries;
    cout << "Printing studentEntries: " << endl;
    printRoster(test);
    */
}

void readRoster(list<string>& roster, string fileName)
{
    //   ifstream course(fileName.c_str());
    ifstream course(fileName); // I am trying it

    string first, last;
    while (course >> first >> last)
        roster.push_back(first + ' ' + last);
    course.close();




    /*// need to insert the file name in the list of students
    for (auto& it : roster) {
        it.push_back(fileName);
    }*/


    //return 0;
}

// printing a list out
void printRoster(const vector<list<string>>& studentEntries)
{
    // well, it works but it prints the list<string< backwords... Whatever, it works for now
    for (const auto& entry : studentEntries)
    {
        for (const auto& course : entry)
        {
            cout << course << " ";
        }
        cout << endl;
    }

    /*for (const auto& str : roster) {
        cout << str << endl;

        for (auto e : str) {
            cout << e << endl;
        }
    }*/

    //return 0;
}


// find if a student is in a list
bool findStudent(list<string>& roster, string student) {
    bool studentFound = false;

    for (auto& it : roster) {
        // if the student is found, return true
        if (it == student) { cout << "Student " << student << " found!" << endl; return true; }
    }

    cout << "Student " << student << " not found." << endl;
    return false;
}



// remove the .txt from the file name
string removeTxt(string str) {
    // placeholder to keep track of the current character in the string
    int currentChar = 0;

    for (auto& it : str) {
        if (it == '.') {
            return str.substr(0, currentChar);
        }

        ++currentChar;
    }

    return "";
}


// search the text file for the student
bool isInTxt(string studentName, string fileName) {
    ifstream course(fileName);

    string first, last;
    while (course >> first >> last) {
        if (studentName == first + " " + last) return true;
    }

    course.close();

    return false;
}