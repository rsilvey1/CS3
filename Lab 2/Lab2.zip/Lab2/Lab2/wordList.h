class WordOccurrence
{
public:
    WordOccurrence(const string& word = "", int num = 0);
    bool matchWord(const string& s) {
        return s == word_;
    }; // returns true if word matches stored
    void increment() { ++num_; }; // increments number of occurrences
    string getWord() const { return word_; };
    int getNum() const { return num_; };

private:
    string word_;
    int num_;
};


// WordOccurrence definitions
/*bool WordOccurrence::matchWord(const std::string &str) {
    if (str == word_)
        return true;
    return false;
};*/

/*void WordOccurrence::increment() {
    ++num_;
}*/
/*
inline string WordOccurrence::getWord() const{
    return string();
};*/


/*int WordOccurrence::getNum() const {
    return num_;
};*/





class WordList
{
public:
    // add copy constructor, destructor, overloaded assignment
    void addWord(const string&);
    void printList();




    // adding the stuff listed above
    WordList(const string s = "", const int size = 0); // default constructor
    void operator=(WordList w) {

    }

private:
    // a dynamically allocated array of WordOccurrences
    // may or may not be sorted
    WordOccurrence* wordArray_;

    int size_;
};
